import os
import sys
import torch
import torch.utils.data
import pickle
import numpy as np
import random
import time
import timeit
import argparse
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
# from input_pipeline import CustomDataPreprocessorForCNN, CustomDatasetForCNN
# from try_model import CNNTrajNet, reshape_output, displacement_error, final_displacement_error, time_elapsed

'''
Model numbering:
(1) normal, mix_all_data               - done with wrong logged losses
(2) normal, specify_test_set           - done with wrong logged losses
(3) fill_0, mix_all_data               - done with wrong logged losses - started Sat night, finished Sun night
(4) fill_0, specify_test_set           - done: started Sun night, finished Mon morning
(5) individual, mix_all_data           - done: started Sun night, finished Mon midnight - needs to multiply loss by 100
(6) individual, specify_test_set       - training on AWS halfway, started Mon midnight; re-training on laptop, Mon noon

path example: rerun_models/model_1/model_[2]_51.tar

'''
# model_n = input('Please enter a model # (e.g. 1, 2, 3...): ')
# if model_n == str(1):
#     print('you rpint 1')
# elif model_n == str(2):
#     print('ewfef3w')
# end_epoch = 5
# for epoch in range(1, end_epoch + 1):
#     print(epoch)
# print('\n(1) Did you save the log/save files from the last train model?'); 
# print('\n(2)'); 
# if_training = False

model_n = str(1)

# test_data_dir = 'model_'+model_n+'/data/test/raw/'
# all_files = os.listdir(test_data_dir)
# print(all_files)
test_data_dir = 'model_'+model_n+'/data/test/'
biwi_files = [os.path.join(test_data_dir+'biwi/', _path) for _path in os.listdir(test_data_dir+'biwi/')]
crowds_files = [os.path.join(test_data_dir+'crowds/', _path) for _path in os.listdir(test_data_dir+'crowds/')]
stanford_files = [os.path.join(test_data_dir+'stanford/', _path) for _path in os.listdir(test_data_dir+'stanford/')]
all_files = biwi_files+crowds_files+stanford_files
files = [biwi_files, crowds_files]
# print(files[0])

# def read_file(_path, delim=' '):
#     data = []
#     with open(_path, 'r') as f:
#         for line in f:
#             line = line.strip().split(delim)
#             line = [float(i) for i in line]
#             data.append(line)
#     return np.asarray(data)

try_data_path = 'model_'+model_n+'/data/try_data.txt'
data = []
c = 0 # line count
with open(try_data_path, 'r') as f:
    for line in f:
        c += 1
        line = line.strip().split(' ')
        # print(line[2:4])
        line = [i for i in line[2:4]]
        data.append(line)

# print(data)
# c = 19
# if c%20 in range(8,20):
# 	print(c)
filename = 'model_1/pretrained_models/okhehe.txt'
# print(os.path.splitext(filename))
# print(' ')
# print(os.path.splitext(filename)[1])

tensor1 = torch.tensor([2.9644, 2.8558, 2.9945, 2.9502, 3.0254, 2.9940, 3.0355, 2.9360, 2.8484, 2.9588, 2.9576, 2.9673])
tensor2 = tensor1 * 100
print(torch.stack((tensor1, tensor2)).size())
# print()


# dataa = read_file(try_data_path)
# print(dataa)

# all_loss = np.loadtxt(try_data_path, delimiter=' ')

# pre_dir='.' if if_training else 'model_'+model_n
# print(pre_dir)
# model_n = str(1)
# rerun_old_log_directory = 'model_'+model_n+'/old_log/'

# detailed_loss_file_name = os.path.join(rerun_old_log_directory, 'train_errors_for_every_'+str(1000)+'th_batch_excluding_testset_'+str([2])+'.txt')
# if os.path.isfile(detailed_loss_file_name):
#     detailed_train_loss = np.loadtxt(detailed_loss_file_name, delimiter=',')
#     count_epoch = 1; train_average_over = 0
#     while count_epoch!=2:
#         count_epoch = detailed_train_loss[train_average_over,0]
#         train_average_over += 1
#     train_average_over -= 1
# else:
#     print('no such file')

# print(train_average_over)


# def train_loss_epoch(epoch, detailed_train_loss, n): # n is the averged over divider
#     return np.sum(detailed_train_loss[n*(epoch-1):n*(epoch-1)+4,2])/n

# print(train_loss_epoch(2, detailed_train_loss, train_average_over))